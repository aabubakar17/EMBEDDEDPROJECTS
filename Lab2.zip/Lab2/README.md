# Abubakar's Lab 2


The code toggles the blue and red led for 3 sec and turn off both led on every random press(for the duration of the press). There are two tasks:
  1. The 'randomPress' tasks simulates a button press at random intervals.
  2. toggleBlueandRed: this toggles the blue and Red LED and turns off both LED on every press
  
The behaviour is described by the following state-transition diagram: 

<img width="643" alt="Lab 2 state diagram" src="https://media.github.research.its.qmul.ac.uk/user/2288/files/14421e80-10b3-11eb-90dd-47cb9ee4189b">
