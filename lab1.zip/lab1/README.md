# Lab 1 Starter Code

Download this code as the start for lab 1. First read it and then run it, before making any changes.

The code flashes one of the on-board LEDs on the KL25Z development board
